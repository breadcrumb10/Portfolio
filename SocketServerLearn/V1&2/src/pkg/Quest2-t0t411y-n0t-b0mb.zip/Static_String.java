package pkg;

import java.io.IOException;
import java.net.*;
import java.io.*;
import java.util.Scanner;

public class Static_String implements AutoCloseable {

	
	//Static String
	public static String send_me = "*bang*";
	public static ServerSocket server;
	public static Scanner Scantastic = new Scanner(System.in); 
	//Main String
	public static void main(String[] args) throws IOException {
		//Establishes a server at port 4999.
		server = new ServerSocket(4999);
		Socket s = null;
		System.out.println("				<Server established>");
		
		//The "heart of the server", will pulse with every iteration
		//
		for (boolean Heart = true; Heart = true;) { 
			//Accepts the socket connection from client - Printer
			//
			System.out.println("		-Attempting to Connect Client-");
			try {s =  server.accept();
			System.out.println("Client connected");}
			catch(IOException ie) {System.out.println("Error: Could not connect Client");}
			
			
			//Sends the Variable to the client.
			//
			try {SendVar(s);}
			catch(Exception e) {System.out.println("Error: Could not send variable.");}
			
			//For Loop for Closing the Server
			//
			for (boolean prompt = true; prompt = true;) {
			
			//The Switch Case for closing server
			int yesno = CURSEYOUSCANNER();
			switch (yesno) {
			
			//Yes - Close the Server
			case 1:
				//Scantastic.close();
				//server.close();
				Heart = false;
				prompt = false;
				break;
			//No - Keep Server Running
			case 2:
				prompt = false;
				break;
			//Default - Run the Prompt again
			default:
				break;
							}/*switch statement*/ 
			break;
			
									
														 }//prompt loop	
			
		}//Heart Loop
		
		
	}//main

	
	//THE ABOMINANLE SCANNER! A CURSE UPON YE!!!
	//THOU SHALT KNOW TRUE FEAR!!!!
	//...This was just to resolve an inf. loop with Try Catch.
	//AND IT DIDN'T WORK! FUCK!!
	private static int CURSEYOUSCANNER() {
		System.out.println("		-Close the Server?-");
		System.out.println();
		System.out.println("	{1: Yes 			2: No}");
		
		
		int yesno = Scantastic.nextInt();
		return yesno;

		
	}



	//Send the variable to client method.
	private static void SendVar(Socket s) throws IOException{
		//"shoots" the variable
		OutputStream outputStream = s.getOutputStream();
		ObjectOutputStream stream = new ObjectOutputStream(outputStream);
			stream.writeObject(send_me);
			stream.flush();
			
			//closes stream
			//stream.close();
													}


	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("Closing resources.");
	}



}//Static_String class

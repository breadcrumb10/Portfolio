package pkg;

import java.io.IOException;
import java.net.*;
import java.io.*;

public class Static_String {

	
	//Static String
	public static String send_me = "*bang*";
	
	
	//Main String
	public static void main(String[] args) throws IOException {
		//Establishes a server at port 4999.
		ServerSocket server = new ServerSocket(4999);
		System.out.println("Server established");
		
		//Accepts the socket connection from client - Printer
		Socket s =  server.accept();
		System.out.println("Client connected");
		
		//Sends the Variable to the client.
		ObjectOutputStream stream = new ObjectOutputStream(
			    new FileOutputStream(send_me));
			stream.writeObject(send_me);
			stream.flush();
		
		//closes the stream and server like a good lad.
		stream.close();
		server.close();
	}



}

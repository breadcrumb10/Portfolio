package pkg;

import java.io.IOException;
import java.net.*;
import java.io.*;

public class Printer {

	public static void main(String[] args) throws IOException{
		//Creates localhost socket 4999
		Socket s = new Socket("localhost",4999);
		
		//The real magic.
		//Gets the input stream from server.
		//Then reads the input.
		InputStreamReader in = new InputStreamReader(s.getInputStream());
		BufferedReader bf = new BufferedReader(in);
		
		//Read input is put into a local string and printed.
		Object var = bf.readLine();
		System.out.println(var);
		
		//Closes the connection, like a good lad.
		s.close();
	}


}
